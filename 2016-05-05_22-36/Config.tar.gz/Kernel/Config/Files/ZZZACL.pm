# OTRS config file (automatically generated)
# VERSION:1.1
package Kernel::Config::Files::ZZZACL;
use strict;
use warnings;
no warnings 'redefine';
use utf8;
sub Load {
    my ($File, $Self) = @_;

# Created: 2016-05-05 22:03:08 (edrfn)
# Changed: 2016-05-05 22:27:12 (edrfn)
$Self->{TicketAcl}->{"001 - Remover \"Close succesful\" e botão \"Close\""} = {
  'Possible' => {},
  'PossibleAdd' => {},
  'PossibleNot' => {
    'Action' => [
      'AgentTicketClose'
    ],
    'Ticket' => {
      'State' => [
        'closed successful'
      ]
    }
  },
  'Properties' => {},
  'PropertiesDatabase' => {},
  'StopAfterMatch' => 0
};

# Created: 2016-05-05 22:15:03 (edrfn)
# Changed: 2016-05-05 22:27:23 (edrfn)
$Self->{TicketAcl}->{"002 - Permitir Fechamento Apenas de Tickets com Serviço"} = {
  'Possible' => {},
  'PossibleAdd' => {
    'Action' => [
      'AgentTicketClose'
    ],
    'Ticket' => {
      'State' => [
        'closed successful'
      ]
    }
  },
  'PossibleNot' => {},
  'Properties' => {
    'Service' => {
      'Name' => [
        '[Not]\'\''
      ]
    }
  },
  'PropertiesDatabase' => {},
  'StopAfterMatch' => 0
};

}
1;
