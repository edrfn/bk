Please see [the upgrading instructions](http://otrs.github.io/doc/manual/admin/5.0/en/html/upgrading.html)
in the online documentation.
