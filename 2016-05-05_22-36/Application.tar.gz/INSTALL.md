Please see [the installation instructions](http://otrs.github.io/doc/manual/admin/5.0/en/html/installation.html)
in the online documentation.
